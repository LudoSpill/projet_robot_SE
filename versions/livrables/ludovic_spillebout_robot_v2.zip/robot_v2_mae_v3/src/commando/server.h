#ifndef SERVER_H
#define SERVER_H

#define PORT_DU_SERVEUR (12346)

extern void Server_start();

extern void Server_stop();

extern void Server_sendMsg(int);

extern void Server_readMsg();

#endif // SERVER_H

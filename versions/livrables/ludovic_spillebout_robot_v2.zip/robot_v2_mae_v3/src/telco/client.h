#ifndef CLIENT_H
#define CLIENT_H

#define PORT_DU_SERVEUR (12346)

typedef struct client
{
    int robot_speed;
    int bump;
    int luminosity;
}Robot_Logs;
extern void Client_start();

extern void Client_stop();

extern void Client_sendMsg(int);

extern Robot_Logs Client_readMsg();


#endif // CLIENT_H

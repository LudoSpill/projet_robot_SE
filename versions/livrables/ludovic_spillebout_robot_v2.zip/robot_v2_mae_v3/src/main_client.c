//#include "./telco/client.h"
#include "./telco/remoteui.h"

int main(){

    RemoteUI_start();
    return 0;
}   
